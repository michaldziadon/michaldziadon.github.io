fetch('https://danepubliczne.imgw.pl/api/data/synop/')
.then(resp=>resp.json())
.then(weatherArray=>{
    
    for(let cityWeather of weatherArray ){
 
        let weatherDiv = document.createElement('div');
        let cityHeading = document.createElement('h2');
        let temperatureElement = document.createElement('p');
        let pressureElement = document.createElement('p');

        weatherDiv.className = 'col-sm-6 col-lg-4 border text-center p-2';

        cityHeading.innerText = cityWeather.stacja;
        temperatureElement.innerText = 'Temperatura: ' + cityWeather.temperatura + ' st. C.';

        let pressure = (cityWeather.cisnienie)?cityWeather.cisnienie:'brak danych';
        pressureElement.innerText = 'Ciśnienie: ' + pressure + ' hPa';

        weatherDiv.appendChild(cityHeading);
        weatherDiv.appendChild(temperatureElement);
        weatherDiv.appendChild(pressureElement);

        document.querySelector('.weather-list').appendChild(weatherDiv);
    }
})